-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 25, 2023 at 09:19 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gwapocarlo`
--

-- --------------------------------------------------------

--
-- Table structure for table `addcart`
--

CREATE TABLE `addcart` (
  `cartId` int(11) NOT NULL,
  `prodId` int(11) NOT NULL,
  `cQuantity` int(11) NOT NULL,
  `cMocktotal` int(11) NOT NULL,
  `cMockstock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(8, 'soup'),
(10, 'carlo gwapo'),
(11, 'gadgets'),
(12, 'papers');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `orderId` int(11) NOT NULL,
  `subTotal` float NOT NULL,
  `discount` float NOT NULL,
  `deduction` float NOT NULL,
  `totalAmount` float NOT NULL,
  `orchange` float NOT NULL,
  `datePurchased` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`orderId`, `subTotal`, `discount`, `deduction`, `totalAmount`, `orchange`, `datePurchased`) VALUES
(1, 152, 10, 15.2, 136.8, 363.2, '6/23/2023, 1:22:11 AM');

-- --------------------------------------------------------

--
-- Table structure for table `orderdetail`
--

CREATE TABLE `orderdetail` (
  `orderDetailsID` int(11) NOT NULL,
  `orderId` int(11) NOT NULL,
  `productId` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `productTotal` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orderdetail`
--

INSERT INTO `orderdetail` (`orderDetailsID`, `orderId`, `productId`, `quantity`, `productTotal`) VALUES
(1, 1, 33, 2, 152);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `category` varchar(150) NOT NULL,
  `name` varchar(150) NOT NULL,
  `units` varchar(150) NOT NULL,
  `stock` int(11) NOT NULL,
  `price` varchar(250) NOT NULL,
  `status` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `category`, `name`, `units`, `stock`, `price`, `status`) VALUES
(1, '3', 'CARLO MAMANGON GESTA', '22', 69, '344', 'Active'),
(7, '6', 'rfrhyfd', 'gfhg', 54, '23', 'Active'),
(11, '9', 'carlo gesta gwapo', 'erdgerfdg', 56, '89', 'Active'),
(12, '9', 'sardines', '56', 78, '34', 'Active'),
(32, '8', 'perla', 'sabon', 105, '67', 'Active'),
(33, '11', 'sds', 'sdv', 74, '76', 'Active'),
(35, '10', 'gfgjghj', 'php', 69, '89', 'Active'),
(36, '11', 'tght', 'hth', 23, '45', 'Active'),
(37, '8', 'discount', 'b', 45, '23', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `stockhistory`
--

CREATE TABLE `stockhistory` (
  `a_Stock_ID` int(11) NOT NULL,
  `prodID` int(11) NOT NULL,
  `added_stock` int(11) NOT NULL,
  `date` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stockhistory`
--

INSERT INTO `stockhistory` (`a_Stock_ID`, `prodID`, `added_stock`, `date`) VALUES
(1, 2, 100, '03/05/2023 11:40:55 pm'),
(2, 2, 56, '03/05/2023 11:42:02 pm'),
(3, 2, 1, '04/05/2023 12:50:40 am'),
(4, 5, 45, '04/05/2023 8:20:10 pm'),
(5, 3, 2, '04/05/2023 8:21:13 pm'),
(6, 6, 69, '04/05/2023 9:34:27 pm'),
(7, 6, 34, '04/05/2023 9:50:44 pm'),
(8, 8, 34, '05/05/2023 8:37:42 am'),
(9, 8, 45, '05/05/2023 8:42:57 am'),
(10, 8, 23, '05/05/2023 8:43:18 am'),
(11, 9, 12, '05/05/2023 8:57:52 am'),
(12, 9, 67, '05/05/2023 8:59:56 am'),
(13, 10, 12, '05/05/2023 9:00:24 am'),
(14, 10, 12, '05/05/2023 10:07:55 am'),
(15, 16, 3, '05/05/2023 11:56:37 am'),
(16, 16, 2, '05/05/2023 11:56:53 am'),
(17, 13, 34, '05/05/2023 4:13:19 pm'),
(18, 17, 45, '5/19/2023, 11:32:03 PM'),
(19, 17, 12, '5/19/2023, 11:41:37 PM'),
(20, 14, 18, '5/19/2023, 11:41:52 PM'),
(21, 14, 18, '5/19/2023, 11:41:52 PM'),
(22, 15, 78, '5/19/2023, 11:42:43 PM'),
(23, 15, 78, '5/19/2023, 11:42:43 PM'),
(24, 15, 78, '5/19/2023, 11:42:43 PM'),
(25, 24, 34, '5/20/2023, 12:55:19 AM'),
(26, 23, 12, '5/20/2023, 12:56:29 AM'),
(27, 28, 34, '5/20/2023, 1:02:09 AM'),
(28, 27, 87, '5/20/2023, 1:08:44 AM'),
(29, 27, 87, '5/20/2023, 1:08:44 AM'),
(30, 28, 12, '5/20/2023, 1:10:35 AM'),
(31, 28, 10, '5/20/2023, 1:10:49 AM'),
(32, 27, 12, '5/20/2023, 1:11:04 AM'),
(33, 28, 23, '5/20/2023, 1:11:46 AM'),
(34, 29, 34, '5/20/2023, 1:26:31 AM'),
(35, 28, 12, '5/20/2023, 1:46:43 AM'),
(36, 32, 32, '5/20/2023, 5:18:15 AM'),
(37, 33, 12, '5/20/2023, 6:53:23 AM'),
(38, 33, 12, '5/20/2023, 6:53:23 AM'),
(39, 32, 34, '5/20/2023, 6:54:01 AM'),
(40, 31, 12, '5/20/2023, 6:54:11 AM'),
(41, 31, 12, '5/20/2023, 6:54:11 AM'),
(42, 28, 12, '5/20/2023, 6:54:29 AM'),
(43, 33, 10, '5/20/2023, 6:54:48 AM'),
(44, 33, 10, '5/20/2023, 6:54:48 AM'),
(45, 33, 9, '5/20/2023, 6:55:10 AM'),
(46, 33, 7, '5/20/2023, 6:55:25 AM'),
(47, 33, 7, '5/20/2023, 6:55:25 AM'),
(48, 32, 1, '5/20/2023, 6:59:55 AM'),
(49, 31, 2, '5/20/2023, 7:02:33 AM'),
(50, 31, 2, '5/20/2023, 7:02:33 AM'),
(51, 33, 1, '5/20/2023, 7:02:53 AM'),
(52, 33, 4, '5/20/2023, 7:03:02 AM'),
(53, 33, 4, '5/20/2023, 7:03:02 AM'),
(54, 32, 2, '5/20/2023, 7:07:29 AM'),
(55, 32, 4, '5/20/2023, 7:07:33 AM'),
(56, 32, 4, '5/20/2023, 7:07:33 AM'),
(57, 28, 2, '5/20/2023, 7:10:01 AM'),
(58, 28, 6, '5/20/2023, 7:10:06 AM'),
(59, 28, 2, '5/20/2023, 7:15:53 AM'),
(60, 35, 2, '5/20/2023, 7:16:02 AM'),
(61, 35, 8, '5/20/2023, 7:16:12 AM'),
(62, 35, 23, '5/20/2023, 12:36:26 PM');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addcart`
--
ALTER TABLE `addcart`
  ADD PRIMARY KEY (`cartId`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`orderId`);

--
-- Indexes for table `orderdetail`
--
ALTER TABLE `orderdetail`
  ADD PRIMARY KEY (`orderDetailsID`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stockhistory`
--
ALTER TABLE `stockhistory`
  ADD PRIMARY KEY (`a_Stock_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addcart`
--
ALTER TABLE `addcart`
  MODIFY `cartId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `orderId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `orderdetail`
--
ALTER TABLE `orderdetail`
  MODIFY `orderDetailsID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `stockhistory`
--
ALTER TABLE `stockhistory`
  MODIFY `a_Stock_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
